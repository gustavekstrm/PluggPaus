import { useEffect, useState } from 'react';

interface GameCard {
  id: string;
  title: string;
  description: string;
  url: string;
  isExternal: boolean;
}

const games: GameCard[] = [
  {
    id: 'wordle',
    title: 'Wordle',
    description: 'Gissa dagens ord på sex försök - spela på New York Times',
    url: 'https://www.nytimes.com/games/wordle/index.html',
    isExternal: true
  },
  {
    id: 'connections',
    title: 'Connections',
    description: 'Hitta grupper av fyra ord som hör ihop - spela på New York Times',
    url: 'https://www.nytimes.com/games/connections',
    isExternal: true
  },
  {
    id: 'contexto',
    title: 'Contexto',
    description: 'Gissa ordet baserat på kontext och likhet - spela på Contexto.me',
    url: 'https://contexto.me/en/',
    isExternal: true
  }
];

function Home() {
  const [lastPlayed, setLastPlayed] = useState<string | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem('lastPlayedGame');
    setLastPlayed(saved);
  }, []);

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20">
      <div className="text-center mb-16 animate-fadeInUp">
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold mb-4 leading-tight">
          <span className="bg-gradient-to-r from-accent-primary via-accent-secondary to-accent-tertiary bg-clip-text text-transparent">
            Tråkig föreläsning?
          </span>
          <br />
          <span className="text-gray-900 dark:text-white">Ta en paus!</span>
        </h1>
        <p className="text-lg sm:text-xl text-gray-700 dark:text-gray-300 font-medium max-w-2xl mx-auto">
          Välj ett spel och utmana dig själv med dagens ordpussel
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 max-w-6xl mx-auto">
        {/* Wordle Card */}
        <div
          className={`group relative overflow-hidden bg-white dark:bg-dark-card rounded-2xl shadow-card hover:shadow-card-hover transition-all duration-500 p-6 sm:p-8 border border-gray-200 dark:border-dark-border hover:border-accent-primary/50 transform hover:-translate-y-2 animate-scaleIn ${
            lastPlayed === 'wordle' ? 'ring-2 ring-accent-primary shadow-glow-md' : ''
          }`}
          style={{ animationDelay: '0s' }}
        >
          <div className="absolute inset-0 opacity-50 dark:opacity-30 bg-gradient-to-br from-indigo-500/10 to-purple-600/10 group-hover:opacity-70 dark:group-hover:opacity-50 rounded-2xl transition-all duration-500 pointer-events-none" />

          <div className="relative z-10">
            <div className="flex justify-between items-start mb-5">
              <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors duration-300">
                Wordle
              </h2>
              {lastPlayed === 'wordle' && (
                <span className="text-xs font-semibold bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-3 py-1.5 rounded-full shadow-glow-sm animate-pulse">
                  Senast spelad
                </span>
              )}
            </div>

            <p className="text-gray-700 dark:text-gray-300 mb-5 min-h-[3rem] leading-relaxed">
              Gissa dagens ord på sex försök - spela på New York Times
            </p>

            <div className="mb-5 flex items-center justify-center gap-2 text-sm text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-dark-surface py-2 px-3 rounded-lg border border-gray-200 dark:border-dark-border">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
              </svg>
              <span className="font-medium">Öppnas på extern webbplats</span>
            </div>

            <a
              href="https://www.nytimes.com/games/wordle/index.html"
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full text-center bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-3.5 sm:py-4 rounded-xl hover:shadow-glow-md transition-all duration-300 font-semibold text-base sm:text-lg transform hover:scale-105 active:scale-95 shadow-lg"
            >
              Spela nu
            </a>
          </div>
        </div>

        {/* Connections Card */}
        <div
          className={`group relative overflow-hidden bg-white dark:bg-dark-card rounded-2xl shadow-card hover:shadow-card-hover transition-all duration-500 p-6 sm:p-8 border border-gray-200 dark:border-dark-border hover:border-purple-600/50 transform hover:-translate-y-2 animate-scaleIn ${
            lastPlayed === 'connections' ? 'ring-2 ring-purple-600 shadow-glow-md' : ''
          }`}
          style={{ animationDelay: '0.1s' }}
        >
          <div className="absolute inset-0 opacity-50 dark:opacity-30 bg-gradient-to-br from-purple-600/10 to-pink-600/10 group-hover:opacity-70 dark:group-hover:opacity-50 rounded-2xl transition-all duration-500 pointer-events-none" />

          <div className="relative z-10">
            <div className="flex justify-between items-start mb-5">
              <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors duration-300">
                Connections
              </h2>
              {lastPlayed === 'connections' && (
                <span className="text-xs font-semibold bg-gradient-to-r from-purple-600 to-pink-600 text-white px-3 py-1.5 rounded-full shadow-glow-sm animate-pulse">
                  Senast spelad
                </span>
              )}
            </div>

            <p className="text-gray-700 dark:text-gray-300 mb-5 min-h-[3rem] leading-relaxed">
              Hitta grupper av fyra ord som hör ihop - spela på New York Times
            </p>

            <div className="mb-5 flex items-center justify-center gap-2 text-sm text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-dark-surface py-2 px-3 rounded-lg border border-gray-200 dark:border-dark-border">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
              </svg>
              <span className="font-medium">Öppnas på extern webbplats</span>
            </div>

            <a
              href="https://www.nytimes.com/games/connections"
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full text-center bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3.5 sm:py-4 rounded-xl hover:shadow-glow-md transition-all duration-300 font-semibold text-base sm:text-lg transform hover:scale-105 active:scale-95 shadow-lg"
            >
              Spela nu
            </a>
          </div>
        </div>

        {/* Contexto Card */}
        <div
          className={`group relative overflow-hidden bg-white dark:bg-dark-card rounded-2xl shadow-card hover:shadow-card-hover transition-all duration-500 p-6 sm:p-8 border border-gray-200 dark:border-dark-border hover:border-pink-600/50 transform hover:-translate-y-2 animate-scaleIn ${
            lastPlayed === 'contexto' ? 'ring-2 ring-pink-600 shadow-glow-md' : ''
          }`}
          style={{ animationDelay: '0.2s' }}
        >
          <div className="absolute inset-0 opacity-50 dark:opacity-30 bg-gradient-to-br from-pink-600/10 to-indigo-600/10 group-hover:opacity-70 dark:group-hover:opacity-50 rounded-2xl transition-all duration-500 pointer-events-none" />

          <div className="relative z-10">
            <div className="flex justify-between items-start mb-5">
              <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white group-hover:text-pink-600 dark:group-hover:text-pink-400 transition-colors duration-300">
                Contexto
              </h2>
              {lastPlayed === 'contexto' && (
                <span className="text-xs font-semibold bg-gradient-to-r from-pink-600 to-indigo-600 text-white px-3 py-1.5 rounded-full shadow-glow-sm animate-pulse">
                  Senast spelad
                </span>
              )}
            </div>

            <p className="text-gray-700 dark:text-gray-300 mb-5 min-h-[3rem] leading-relaxed">
              Gissa ordet baserat på kontext och likhet - spela på Contexto.me
            </p>

            <div className="mb-5 flex items-center justify-center gap-2 text-sm text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-dark-surface py-2 px-3 rounded-lg border border-gray-200 dark:border-dark-border">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
              </svg>
              <span className="font-medium">Öppnas på extern webbplats</span>
            </div>

            <a
              href="https://contexto.me/en/"
              target="_blank"
              rel="noopener noreferrer"
              className="block w-full text-center bg-gradient-to-r from-pink-600 to-indigo-600 text-white py-3.5 sm:py-4 rounded-xl hover:shadow-glow-md transition-all duration-300 font-semibold text-base sm:text-lg transform hover:scale-105 active:scale-95 shadow-lg"
            >
              Spela nu
            </a>
          </div>
        </div>
      </div>
    </main>
  );
}

export default Home;
